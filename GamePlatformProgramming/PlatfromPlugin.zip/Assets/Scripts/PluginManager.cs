using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PluginManager : MonoBehaviour
{
#if UNITY_ANDROID
    private AndroidJavaObject m_AndroidJavaObject;
    private AndroidJavaObject m_ActivityInstance;
#elif UNITY_IOS
#endif
    int nNavitiveData = 0;
    // Start is called before the first frame update
    void Start()
    {
        Debug.LogWarning("PluginManager.AndroidJavaObject 1:" + m_AndroidJavaObject);
#if UNITY_ANDROID
        using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            m_ActivityInstance = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
        }
        m_AndroidJavaObject = new AndroidJavaObject("com.sbsgame.android.unityandroidplugin.Plugin");

        m_AndroidJavaObject.Call("SetAcivity", m_ActivityInstance);
#endif
        Debug.LogWarning("PluginManager.AndroidJavaObject 2:" + m_AndroidJavaObject);
    }

    private void OnGUI()
    {
        nNavitiveData = GetInt();

        if (m_AndroidJavaObject != null)
        {
            GUI.Box(new Rect(0, 0, 200, 20), "GetInt:" + nNavitiveData);
            if(GUI.Button(new Rect(0, 20, 200, 20), "ShowToast"))
            {
                ShowToastMsg("Test!!!");
            }
            if (GUI.Button(new Rect(0, 40, 200, 20), "����"))
            {
                ShowAlertDialog("�ȳ�","�����մϱ�?","����","���");
            }
        }
        else
            GUI.Box(new Rect(0, 0, 200, 20), "Plugin Load Failed!");
    }

    public int GetInt()
    {
        int nResult = -1;
#if UNITY_ANDROID
        nResult = m_AndroidJavaObject.Call<int>("GetInt");
#endif
        return nResult;
    }

    public void ShowToastMsg(string msg)
    {
#if UNITY_ANDROID
        m_AndroidJavaObject.Call("ToastMSG",msg);
#endif
    }

    public void ShowAlertDialog(string tilte, string msg, string positive, string negative)
    {
        m_AndroidJavaObject.Call("ShowAlertDialog", tilte,msg,positive,negative);
    }
}
