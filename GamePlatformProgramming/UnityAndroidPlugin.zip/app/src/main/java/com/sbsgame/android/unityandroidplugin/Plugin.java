package com.sbsgame.android.unityandroidplugin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

public class Plugin {
    static Activity m_Activity = null;
    //유니티로부터 액티비티를 받음.
    void SetAcivity(Activity activity)
    {
        m_Activity = activity;
    }
    //유니티에 1000값을 리턴함
    int GetInt()
    {
        return 1000;
    }
    void ToastMSG(String msg)
    {
        Toast.makeText(m_Activity, msg, Toast.LENGTH_LONG).show();
    }
    void ShowAlertDialog(String title, String msg, String positive, String negative)
    {
        AlertDialog.Builder msgBuilder = new AlertDialog.Builder(m_Activity)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(positive, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        m_Activity.finish();
                    }
                })
                .setNegativeButton(negative, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        AlertDialog msgDlg = msgBuilder.create();
        msgDlg.show();
    }
}

