using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HierarchyChilde : MonoBehaviour
{
    public List<Transform> transformArms;
    public List<Vector3> vecArms;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = transformArms.Count-1; i >= 0; i--)
        {
            Transform trChild = transformArms[i];

            if (trChild.parent)
            {

                Transform trParent = trChild.parent;
                Matrix4x4 matParant = trParent.localToWorldMatrix;
                trChild.gameObject.name = string.Format("{0}({1})", trChild.gameObject.name, trParent.gameObject.name);
            }
            else
                trChild.gameObject.name = string.Format("{0}({1})", trChild.gameObject.name, "null");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnGUI()
    {
        int h = 120;
        int w = 300;
        for (int i = 0; i < transformArms.Count; i++)
        {
            string strMsg = string.Format("name:{0}\n{1}\nlocal/World:{2}/{3}\n", 
                                            transformArms[i].gameObject.name, 
                                            transformArms[i].localToWorldMatrix, 
                                            transformArms[i].localPosition, transformArms[i].position);
            GUI.Box(new Rect(i, i*h, w, h),strMsg);
        }
    }

    private void OnDrawGizmos()
    {
        for (int i = 0; i < transformArms.Count; i++)
        {
            Transform trChild = transformArms[i];
            Vector3 vPos = trChild.localPosition;
            Vector3 vCurPos = vPos;
            if (trChild.parent)
            { 
                Transform trParent = trChild.parent;
                Matrix4x4 matParant = trParent.localToWorldMatrix;
               
                vCurPos = matParant.MultiplyPoint(vPos);
            }
            if (i == 0) Gizmos.color = Color.red;
            if (i == 1) Gizmos.color = Color.green;
            if (i == 2) Gizmos.color = Color.blue;
            Gizmos.DrawCube(vCurPos, trChild.localScale);
        }
        for (int i = 0; i < transformArms.Count; i++)
        {
            if (i == 0) Gizmos.color = Color.red;
            if (i == 1) Gizmos.color = Color.green;
            if (i == 2) Gizmos.color = Color.blue;
            Gizmos.DrawWireCube(transformArms[i].localPosition, transformArms[i].localScale);
        }
    }
}
