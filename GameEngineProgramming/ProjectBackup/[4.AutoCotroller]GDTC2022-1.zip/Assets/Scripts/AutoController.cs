using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoController : MonoBehaviour
{
    public PlayerController playerController;
    public float Site;
    public float Range;

    public GameObject objTarget;

    public bool isShot = false;

    public void ShotOn()
    {
        StartCoroutine(ProcessShot(1));
    }

    public void ShotOff()
    {
        isShot = false;
    }

    IEnumerator ProcessShot(float time)//2
    {
        Debug.Log("ProcessShot 1: " + time);
        isShot = true;
        while (isShot)
        {
            playerController.Lookat(objTarget);
            playerController.Shot();
            yield return new WaitForSeconds(time);//2
        }
        Debug.Log("ProcessShot 2: " + time);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       if(objTarget != null)
        {
            //if (isShot == false) ShotOn();
            Vector3 vPlayerPos = playerController.transform.position;
            Vector3 vTargetPos = objTarget.transform.position;
            float fTargetDist = Vector3.Distance(vPlayerPos, vTargetPos);
            Vector3 vTargetDir = vTargetPos - vPlayerPos;

            if (fTargetDist >= Range)
            {
                if (isShot) ShotOff();
                playerController.MoveProcess(vTargetDir.normalized);
                Debug.DrawLine(vPlayerPos, vTargetPos, Color.red);
            }
            else
            {
                Debug.DrawLine(vPlayerPos, vTargetPos, Color.green);
                if (!isShot) ShotOn();
            }
        }
    }

    private void FixedUpdate()//�������� �浹ó���ÿ� �����.
    {
        Collider[] colliders = Physics.OverlapSphere(playerController.transform.position, Site);

        bool bCheck = false;
        foreach(var collider in colliders)
        {
            if (collider.gameObject.name != playerController.gameObject.name &&
                collider.tag == "Player")
            {
                if (objTarget == null)
                    objTarget = collider.gameObject;
             
                bCheck = true;
            }
        }

        if (bCheck == false)
        {
            objTarget = null;
            isShot = false;
        }
    }

    private void OnDrawGizmos()//�浹������ �����ֱ����Ͽ� �߰�
    {
       
        Gizmos.DrawWireSphere(playerController.transform.position, Site);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(playerController.transform.position, Range);
    }
}
