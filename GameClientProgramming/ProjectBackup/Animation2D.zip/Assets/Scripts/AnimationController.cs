using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationController : MonoBehaviour
{
    public Animator animator;
    public float Speed = 1;
    public float JumpPower;
    public bool isJump = false;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        //animator.SetInteger("SetState", 1);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            animator.SetInteger("SetState", 1);
            transform.position += Vector3.left * Speed * Time.deltaTime;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        if (Input.GetKeyUp(KeyCode.A))
        {
            animator.SetInteger("SetState", 0);
        }

        if (Input.GetKey(KeyCode.D))
        {
            animator.SetInteger("SetState", 1);
            transform.position += Vector3.right * Speed * Time.deltaTime;
            transform.localScale = new Vector3(1, 1, 1);
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            animator.SetInteger("SetState", 0);
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            animator.SetInteger("SetState", 2);
        }
        if (Input.GetKeyUp(KeyCode.S))
        {
            animator.SetInteger("SetState", 0);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("Space");
            JumpStart();

            //animator.SetTrigger("hurt");
        }

        Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
        Vector3 vPos = this.transform.position;
        Vector3 vEndPos = vPos + new Vector3(rigidbody.velocity.x, rigidbody.velocity.y, 0);
        Debug.DrawLine(vPos, vEndPos);

        UpdateJump();
    }

    void JumpStart()
    {
        Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
        rigidbody.AddForce(Vector3.up * JumpPower);
        animator.SetInteger("SetState", 5);
        isJump = true;
    }

    void UpdateJump()
    {
       

        if(isJump)
        {
            Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();

            Debug.Log("UpdateJump"+rigidbody.velocity);

            if (rigidbody.velocity.y > 0)
                animator.SetInteger("SetState", 5);
            else
                animator.SetInteger("SetState", 6);
        }
    }    

    void JumpEnd()
    {
        if (isJump)
        {
            animator.SetInteger("SetState", 0);
            isJump = false;
        }
    }

    private void OnGUI()
    {
        AnimatorClipInfo[] aniClipinfo = animator.GetCurrentAnimatorClipInfo(0);
        AnimatorStateInfo aniStatusInfo = animator.GetCurrentAnimatorStateInfo(0);

        string log = string.Format("{0}:{1}", aniClipinfo[0].clip.name, aniStatusInfo.normalizedTime);
        GUI.Box(new Rect(0, 0, 500, 20), log);

        //if (aniClipinfo[0].clip.name == "hurt")
        //{
        //    Debug.Log("hurt!!!!");
        //    if (aniStatusInfo.normalizedTime >= 1)
        //    {
        //        Debug.Log("hurt end!");
        //        animator.SetInteger("SetState", 0);
        //    }
        //}
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("OnCollisionEnter2D:" + collision.gameObject.name);
        JumpEnd();
        //animator.SetInteger("SetState", 4);   
    }
}