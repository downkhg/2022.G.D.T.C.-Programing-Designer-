using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EqumentSystem : MonoBehaviour
{
    public GameObject m_objRightWepon;
    public GameObject m_objLeftWepon;

    public Transform m_trRightHand;
    public Transform m_trLeftHand;

    public Transform m_trRightSlot;
    public Transform m_trLeftSlot;

    bool m_bEquemt = false;

    public bool CheckEqument
    {
        get { return m_bEquemt; }
    }

    void InitParentObject(GameObject obj, Transform parent)
    {
        obj.transform.parent = parent;
        obj.transform.localRotation = Quaternion.identity;
        obj.transform.localPosition = Vector3.zero;
    }

    public void SetItem()
    {
        InitParentObject(m_objLeftWepon, m_trLeftHand);
        InitParentObject(m_objRightWepon, m_trRightHand);
        
        m_bEquemt = true;
    }

    public void ReleaseItem()
    {
        InitParentObject(m_objLeftWepon, m_trLeftSlot);
        InitParentObject(m_objRightWepon, m_trRightSlot);
        m_bEquemt = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        m_objLeftWepon = Instantiate(m_objLeftWepon, m_trLeftSlot);
        m_objRightWepon = Instantiate(m_objRightWepon, m_trRightSlot);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Tab))
        {
            if (m_bEquemt)
                ReleaseItem();
            else
                SetItem();
        }
    }
}
