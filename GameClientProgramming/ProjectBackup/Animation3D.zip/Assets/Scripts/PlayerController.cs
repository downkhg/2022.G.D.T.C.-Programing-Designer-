using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Animator m_cAnimator;

    public float m_fSpeed;

    float m_fMove;
    float m_fRoat;

    public int m_nAtk = 1;

    public EqumentSystem m_cEquentSystem;

    // Start is called before the first frame update
    void Start()
    {
        m_cAnimator = GetComponent<Animator>();
        m_cEquentSystem = GetComponent<EqumentSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        m_fMove = Input.GetAxis("Vertical");
        m_fRoat = Input.GetAxisRaw("Horizontal");

        Vector3 vMove = Vector3.forward * m_fMove * m_fSpeed * Time.deltaTime;

     
        m_cAnimator.SetFloat("run", m_fMove);
        transform.Translate(vMove);
    

        transform.Rotate(Vector3.up * m_fRoat);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            //if(m_cEquentSystem.CheckEqument)
                m_cAnimator.SetTrigger("attack");
        }
    }

    private void OnGUI()
    {
        GUI.Box(new Rect(0, 0, 100, 20), string.Format("Vertical:{0}",m_fMove));
        GUI.Box(new Rect(0, 20, 100, 20), string.Format("Horizontal:{0}",m_fRoat));
    }
}
