using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sendback : MonoBehaviour
{
    public Material m_cMaterial;
    public int m_nHp;
    int m_nMaxHp;

    public void Hit(int demage)
    {
        if (!m_bHit)
        {
            StartCoroutine(ProcessHit(0.5f));
            m_nHp -= demage;
        }
    }

    public void ResetHP()
    {
        m_nHp = m_nMaxHp;
    }

    public bool CheckHit {get { return m_bHit; }}
    bool m_bHit;
    IEnumerator ProcessHit(float time)
    {
        m_bHit = true;
        m_cMaterial.color = Color.red;
        yield return new WaitForSeconds(time);
        m_cMaterial.color = Color.white;
        m_bHit = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        m_nMaxHp = m_nHp;
        //m_cMaterial.color = Color.red;
        //Hit();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
            ResetHP();
    }

    private void OnGUI()
    {
        GUI.Box(new Rect(100, 0, 100, 20),string.Format("{0}/{1}",m_nHp,m_nMaxHp));
    }
}
