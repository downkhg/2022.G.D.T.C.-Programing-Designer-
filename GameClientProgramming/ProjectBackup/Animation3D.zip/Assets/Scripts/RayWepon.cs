using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayWepon : MonoBehaviour
{
    public float m_fRange = 1;
    public LayerMask m_sTargetLayer;
 
    private void FixedUpdate()
    {
        Vector3 vPos = this.transform.position;
        Vector3 vEndPos = vPos + this.transform.forward * m_fRange;

        if(Physics.Raycast(vPos, transform.forward, m_fRange))
        {
            GameManager.GetInstance().EventHitSendBack();
            Debug.DrawLine(vPos, vEndPos, Color.green);
        }
        else
            Debug.DrawLine(vPos, vEndPos, Color.red);
    }
}
