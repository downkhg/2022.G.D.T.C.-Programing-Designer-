using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public PlayerController m_cPlayerController;
    public Sendback m_cSendBack;

    static GameManager m_cInstacne;

    public static GameManager GetInstance()
    {
        return m_cInstacne;
    }

    // Start is called before the first frame update
    void Start()
    {
        m_cInstacne = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void EventHitSendBack()
    {
        if(m_cPlayerController.m_cEquentSystem.CheckEqument)
            m_cSendBack.Hit(m_cPlayerController.m_nAtk);
    }
}
